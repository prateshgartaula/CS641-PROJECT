import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-final-end-page',
  templateUrl: './final-end-page.component.html',
  styleUrls: ['./final-end-page.component.css']
})
export class FinalEndPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
